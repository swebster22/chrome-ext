"use strict";
/***
let navWidth, isToggled = false;

const LEVEL_ERROR = "warning";
const LEVEL_WARN = "info";
const LEVEL_INFO = "promo";
const observer = new MutationObserver((e) => {
  observer.disconnect();
  $('.github-alert').remove();  
});
***/

/***
$(() => {  
  initPageContent() 
  .then(initPageEvent)
  .catch((err) => {
    switch (err.message) {
      case "nothing" :
        break;
      default:
        showAlert("Unknow Error", LEVEL_ERROR);
        break;
    }
  });
});
***/
$(() => {  
  initPageContent() 
});

function initPageContent() {
  return Promise.all([
  //$.get(chrome.runtime.getURL('content/toggleBar.html'))
    $.get(chrome.runtime.getURL('content/multilangBar.html'))
   
  ])
  .then((content) => {
    //$('#undoButton').before(content[0]);
    $('.sites-header-cell-buffer-wrapper').after(content[0]);
  })
  .then(() => {
    chrome.runtime.sendMessage({ cmd: "tab" });
  });
}
/***
function initPageEvent() {
 ['sidebarToggle'].forEach((type) => {
    $(document).on('mouseover', `#${type}Button`, () => {
      $(`#${type}Button`).addClass('goog-toolbar-button-hover');
    });

   
    $(document).on('mouseleave', `#${type}Button`, () => {
      $(`#${type}Button`).removeClass('goog-toolbar-button-hover');
    });
    
    $(document).on('click', `#${type}Button`, () => {



     var resourceListPanel = $('.resource-list').parent();
     var dragHandle = $('.gwt-SplitLayoutPanel-HDragger').parent();
     var  editorPanel = $('.gwt-TabLayoutPanel').parent();
     isToggled = !isToggled;

     $( window ).unload(function() {
       navWidth = "250px";
       resourceListPanel.css('width',navWidth)
       dragHandle.css('left',navWidth);
       editorPanel.css('left',  parseInt(dragHandle.css('left')) +9 );
      });

      if(isToggled){
       $(`#${type}Button`).addClass('goog-toolbar-button-active');          
       navWidth =  resourceListPanel.css('width'); 

       resourceListPanel.css('width','2px')
       dragHandle.css('left','2px');
       editorPanel.css('left','2px');      
       
       resourceListPanel.on('mouseenter',function(){
           resourceListPanel.css('width',navWidth)
           dragHandle.css('left',navWidth);
           editorPanel.css('left',  parseInt(dragHandle.css('left')) +9 );
       });
       
       resourceListPanel.on('mouseleave',function(){
       resourceListPanel.css('width','2px')
       dragHandle.css('left','2px');
       editorPanel.css('left','2px');
       });
      }else{
      $(`#${type}Button`).removeClass('goog-toolbar-button-active');
       resourceListPanel.css('width',navWidth)
       dragHandle.css('left',navWidth);
       editorPanel.css('left',  parseInt(dragHandle.css('left')) +9 );
      
      resourceListPanel.off('mouseenter');
      resourceListPanel.off('mouseleave');
      }
      
    });
  });

  $(document).on('click', '.github-alert-dismiss', () => {
    $('.github-alert').remove();
  });
}
***/

/* show alert using gas ui
 * level: info, warning, error
 * but the class is promo. info, warning
 */
 /***
function showAlert(message, level=LEVEL_INFO) {
  $.get(chrome.runtime.getURL('content/alert.html'))
  .then((content) => {
    observer.disconnect();
    $('#docs-butterbar-container').empty().append(content.replace(/_LEVEL_/g, level).replace(/_MESSAGE_/, message));
    observer.observe(document.getElementById('docs-butterbar-container'), { childList: true });
  })
}
***/
String.prototype.capitalize = function() {
    return this.charAt(0).toUpperCase() + this.slice(1);
}

chrome.runtime.onMessage.addListener(
  function(resultArray, sender, sendResponse) {
    //console.log(sender.tab ?
    //            "from a content script:" + sender.tab.url :
    //            "from the extension");
    //if (request.greeting == "hello")
    //  sendResponse({farewell: "goodbye"});
    //
    //
    //
    // sendResponse({receivedMsg: "gotIt"});
    //
    //
    // initPageContent();
      // if (!resultArray) { return; }
      if (resultArray == "Master URL lookup failed." || !resultArray) { 
        console.log(resultArray); 
        $('#changeLabel').html("Article disponible uniquement pour cette langue.");  // Change Request: Article uniquement disponible en Français  // Article disponible uniquement pour cette langue
        $('#changeLabel').show();
        return; 
      }
      // Function getActiveList:: countryName = Sales Bible STEVE and pageUrl = https://sites.google.com/a/doctolib.fr/sales-bible-steve/formation
      console.log("Document Ready .. call back: "+ resultArray);
      if (resultArray) {
        $('#chooseCountry').children().remove(); // clear any existing options
        $('#chooseCountry').append($("<option selected></option>").text("Choose country"));
        //
        for (var i=0; i<resultArray.length; i++) {
          var countryName = resultArray[i][0];
          var countryUrl = resultArray[i][1];
          console.log("Document Ready .. countryName / countryUrl = "+countryName+" / "+countryUrl); 
          $('#chooseCountry').append($("<option value="+countryUrl+"></option>").text(countryName)); 
        }
      } 
      if (resultArray.length <1) {    // was 2 but changed to 1
        $('#changeLabel').html("Country/Language: none found");
        $('#chooseCountry').hide();
        $('#changeLabel').show();
      } else {
        $('#changeLabel').html("Country/Language: ");
        $('#changeLabel').show();
        $('#chooseCountry').show();
      }
      //$('#inTurnFadingTextG').hide();
      // $('#changeBody').show();
      // $('#rightBody').html(rightBodyHtml);
      // $('#viewMore').show();
  //}

  });